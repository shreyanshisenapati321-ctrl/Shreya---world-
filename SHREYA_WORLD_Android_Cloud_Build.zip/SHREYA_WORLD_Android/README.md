# SHREYA WORLD — Android project 🎀

This project contains a small offline-first Android app prototype. The game UI runs locally in an Android WebView. It includes avatar outfit choices, room themes, pet selection, mini-game coin rewards, level-ups, and local save state.

## Build the APK without a computer (GitHub Actions)

You need a GitHub account and a mobile browser. GitHub will compile the APK on its cloud computers.

1. Download and extract `SHREYA_WORLD_Android_Project.zip` on your phone.
2. In your browser, open https://github.com/new and create a **Public** repository named `shreya-world` (a private repo also works if Actions are enabled).
3. On the new repository page, choose **Add file → Upload files**. Upload the contents of the extracted `SHREYA_WORLD_Android` folder, keeping the folder structure. Include the `.github/workflows/android.yml` file. If the mobile file picker cannot select the hidden `.github` folder, create the workflow manually:
   - Choose **Add file → Create new file**.
   - Enter `.github/workflows/android.yml` as the filename.
   - Paste the workflow contents from the file at that path in this ZIP.
   - Commit the new file.
4. Commit/upload the project files to the `main` branch. The workflow should start automatically. If it does not, open the repository's **Actions** tab, choose **Build SHREYA WORLD APK**, tap **Run workflow**, then confirm.
5. Wait for the run to finish with a green check. Open that run, scroll to **Artifacts**, and download `SHREYA-WORLD-debug-APK`.
6. Extract the downloaded artifact ZIP. It contains `app-debug.apk`.
7. Tap `app-debug.apk` on your OPPO phone and follow Android's install prompts. If asked, allow your browser or file manager to install unknown apps for this installation. Only install APKs you built from this project.

## If GitHub Actions fails

Open the failed run and check the first red error step. Make sure all project files were uploaded to the repository root (so `settings.gradle` and `app/` are at the top level), and that `.github/workflows/android.yml` is present on `main`.

## App limitations

- This is a starter prototype, not a full 3D or multiplayer game.
- It has no online accounts, public chat, payments, ads, or location access.
- The debug APK is suitable for personal testing. A Play Store release would need a separately signed release build.
